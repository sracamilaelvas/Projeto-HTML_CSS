document.addEventListener('DOMContentLoaded',()=>{
const tarefas=JSON.parse(localStorage.getItem('tarefas'))||[];
const lista=document.getElementById('listaTarefas');
const modalTarefa=document.getElementById('modalTarefa');
const modalDetalhes=document.getElementById('modalDetalhes');

function render(){
if(!lista)return;lista.innerHTML='';
tarefas.forEach((t,i)=>{
const li=document.createElement('li');
li.innerHTML=`<span>${t.titulo}</span>
<div><button onclick="verDetalhes(${i})">👁️</button>
<button onclick="editar(${i})">✏️</button>
<button onclick="excluir(${i})">🗑️</button></div>`;
lista.appendChild(li);
});localStorage.setItem('tarefas',JSON.stringify(tarefas));
}

window.verDetalhes=i=>{
const t=tarefas[i];
modalDetalhes.classList.remove('hidden');
document.getElementById('detalheTitulo').textContent='Título: '+t.titulo;
document.getElementById('detalheDescricao').textContent='Descrição: '+t.descricao;
document.getElementById('detalheStatus').textContent='Status: '+t.status;
};

window.editar=i=>{
const t=tarefas[i];
document.getElementById('tarefaId').value=i;
document.getElementById('tituloTarefa').value=t.titulo;
document.getElementById('descricaoTarefa').value=t.descricao;
document.getElementById('statusTarefa').value=t.status;
modalTarefa.classList.remove('hidden');
};

window.excluir=i=>{
if(confirm('Excluir esta tarefa?')){tarefas.splice(i,1);render();}
};

document.getElementById('novaTarefa')?.addEventListener('click',()=>{
document.getElementById('formTarefa').reset();
modalTarefa.classList.remove('hidden');
document.getElementById('tarefaId').value='';
});

document.getElementById('cancelar')?.addEventListener('click',()=>modalTarefa.classList.add('hidden'));
document.getElementById('fecharDetalhes')?.addEventListener('click',()=>modalDetalhes.classList.add('hidden'));

document.getElementById('formTarefa')?.addEventListener('submit',e=>{
e.preventDefault();
const id=document.getElementById('tarefaId').value;
const nova={titulo:tituloTarefa.value,descricao:descricaoTarefa.value,status:statusTarefa.value};
if(id)tarefas[id]=nova;else tarefas.push(nova);
modalTarefa.classList.add('hidden');render();
});

render();
});